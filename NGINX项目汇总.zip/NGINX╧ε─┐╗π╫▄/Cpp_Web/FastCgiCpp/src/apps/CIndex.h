/////////////////////////////////////////////
///COPYRIGHT NOTICE
/// Copyright (c) 2018
/// All rights reserved.
///
/// @file CIndex.h
/// @brief 初始页面
///
/// @version 1.0
/// @author liukang
/// @date 2018.01.10
//////////////////////////////////////////////
#pragma once

#include "../main.h"

class  CIndex
{
public:
    CIndex() = default;
    ~CIndex() = default;

    Response index(Request req);


private:

};
