var searchData=
[
  ['tlogsingle',['TLogSingle',['../TLog_8h.html#a3e46b455ecd8d95724aa95fb379b0099',1,'TLog.h']]]
];
