var searchData=
[
  ['singleton',['Singleton',['../classSingleton.html',1,'']]]
];
