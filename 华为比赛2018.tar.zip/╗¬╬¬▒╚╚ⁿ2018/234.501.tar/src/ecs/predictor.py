# coding=utf-8
import datetime
data_beg = datetime.datetime.today()
data_end = datetime.datetime.today()
from mat import *
import random
import math


class ReqFlavor(object):
    def __init__(self, name, cpu, mem, data):
        self.name = name
        self.cpu = cpu
        self.mem = mem
        self.data = data
        self.pre_val = predict(self.name, self.data)


class Serverdraw(object):

    def __init__(self, cpu, mem):
        self.cpu = cpu
        self.mem = mem


class Serverin():

    def __init__(self):
        self.totalcpu = 0
        self.totalmem = 0
        # self.servernum = 0
        self.vm_list = []


def standRegres(xArr, yArr):
    xMat = mat(xArr)
    yMat = mat(yArr).T
    xTx = xMat.T * xMat
    # 检查行列式是否为0（有必要）
    if xTx.det() == 0.0:
        # if linalg.det(xTx)== 0.0:
        print "This matrix is singular, cannot do inverse"
        return []
    ws = xTx.I * (xMat.T * yMat)
    return ws


def train_test_split(train_list):
    # split
    train_x = []
    train_y = []
    test_x = train_list[-8:]
    for i in range(len(train_list) - 8):
        train_x.append(train_list[i:i + 8])
        train_y.append(train_list[i + 8])
    return train_x, train_y, test_x

def outlier_judge(data_list,train_list):
    train_x,train_y,test_x = train_test_split(train_list)
    xMat = mat(train_x)
    yMat = mat(train_y)
    #regression
    ws=standRegres(train_x,train_y)
    if ws==[]:
        raise Exception("ws error")
    yHat=xMat*ws

    y1=[]
    y2=[]
    for i in yHat.toList():
        for j in i:
            y1.append(j)
    for i in yMat.toList():
        for j in i:
            y2.append(j)

    rmse = map(lambda x:(x[0]-x[1])**2,zip(y1,y2)) 
    #rmse = map(lambda x:(x[0]-x[1])**2,zip(yHat,train_y))    
    rserror = sum(rmse)
    rssum=0
    for i in range(len(rmse)):
        rssum += (rmse[i]-rserror/len(rmse))**2
    sigma = math.sqrt(rssum/len(rmse))
    #print sigma
    
    outlier_thred_high = rserror/len(rmse)+3*sigma
    outlier_thred_low = rserror/len(rmse)-3*sigma
    
    return yHat,rmse,outlier_thred_high,outlier_thred_low

def outlier_process(data_list,train_list):
    mean=sum(train_list)*1.0/len(train_list)
    val=0
    for i in train_list:
        val+=(i-mean)**2
    val = val*1.0/len(train_list)
    sigma = math.sqrt(val)
    for i in range(8):
        print train_list[i]
        if train_list[i]>(mean+sigma) or train_list[i]<(mean-sigma):
            train_list[i]=mean            
    try:
        yHat,rmse,outlier_thred_high,outlier_thred_low = outlier_judge(data_list,train_list)  
    except Exception:
        raise Exception,"ws = []"
    else:         
        for i in range(len(rmse)):
            if rmse[i]>outlier_thred_high or rmse[i]<outlier_thred_low:
                train_list[i+8]=int(round(yHat.toList()[i][0]))
                #train_list[i+7]=train_list[i+6]
                try:
                    yHat,rmse,outlier_thred_high,outlier_thred_low = outlier_judge(data_list,train_list)  
                except Exception:
                    raise Exception,"ws = []"
                else:
                    continue
        return train_list


def outlier_judge1(data_list,train_list):
    x_avg = sum(data_list)*1.0/len(data_list)
    y_avg = sum(train_list)*1.0/len(train_list)
    x2_sum = 0
    xy_sum = 0
    for i in range(len(data_list)):
        x2_sum += data_list[i]**2
        xy_sum += train_list[i]*data_list[i]
    x2_avg = x2_sum*1.0/len(data_list)
    xy_avg = xy_sum*1.0/len(data_list)
    a=(xy_avg-x_avg*y_avg)*1.0/(x2_avg-x_avg**2)
    b=y_avg-a*x_avg
    y_pre=[]
    for i in range(len(data_list)):
        yHat =a*data_list[i]+b
        y_pre.append(yHat)
    rmse = map(lambda x:(x[0]-x[1])**2,zip(y_pre,train_list)) 
    rserror = sum(rmse)
    rssum=0
    for i in range(len(rmse)):
        rssum += (rmse[i]-rserror/len(rmse))**2
    sigma = math.sqrt(rssum/len(rmse))
    #print sigma
    
    outlier_thred_high = rserror/len(rmse)+3*sigma
    outlier_thred_low = rserror/len(rmse)-3*sigma
    
    return yHat,rmse,outlier_thred_high,outlier_thred_low

def outlier_process1(data_list,train_list):
    yHat,rmse,outlier_thred_high,outlier_thred_low = outlier_judge1(data_list,train_list)    
    for i in range(len(train_list)):
        if rmse[i]>outlier_thred_high or rmse[i]<outlier_thred_low:
            if i>=7:
                train_list[i]=sum(train_list[i-7:i])/7
            else:
                train_list[i]=sum(train_list[i+1:i+8])/7
            yHat,rmse,outlier_thred_high,outlier_thred_low = outlier_judge1(data_list,train_list) 

    return train_list

def linear_regression_predict(train_list):
    train_x, train_y, test_x = train_test_split(train_list)
    ws = standRegres(train_x, train_y)
    if ws==[]:
        yHat = mat(sum(test_x)*1.0/len(test_x))
    else:
        yHat = mat(test_x) * ws
    
    return yHat

def exponential_smoothing(alpha, s):
    """
    s2 = np.zeros(s.shape)
    s2[0] = s[0]
    for i in range(1, len(s2)):
        s2[i] = alpha*s[i]+(1-alpha)*s2[i-1]
    return s2
    """
    s2 = [0]*len(s)
    s2[0] = s[0]
    for i in range(1, len(s2)):
        s2[i] = alpha*s[i]+(1-alpha)*s2[i-1]
    return s2

def naive_model(data_list, train_list):
    # 异常值处理
    #train_list = outlier_process(train_list)
    #train_list = outlier_process1(data_list, train_list)
    #######naive model ############
    pre1 = sum(train_list[-((data_end - data_beg).days):])
    if pre1<0:
        pre1=0
    print "pre1",pre1
    return pre1

def lsm__1st_model(data_list, train_list,endTime):
    #######Lsm 1st model (30days)########
    #train_list = outlier_process(train_list)
    train_list = outlier_process1(data_list, train_list)
    x_avg = sum(data_list[-30:]) * 1.0 / 30
    y_avg = sum(train_list[-30:]) * 1.0 / 30
    x2_sum = 0
    xy_sum = 0
    for i in range(30):
        x2_sum += data_list[-(i + 1)] ** 2
        xy_sum += train_list[-(i + 1)] * data_list[-(i + 1)]
    x2_avg = x2_sum * 1.0 / 30
    xy_avg = xy_sum * 1.0 / 30
    a = (xy_avg - x_avg * y_avg) * 1.0 / (x2_avg - x_avg ** 2)
    b = y_avg - a * x_avg
    pre2 = 0
    time_spam = (data_beg -endTime).days-1
    for i in range(len(data_list)+time_spam, len(data_list) + (data_end - data_beg).days+time_spam):
        pre2 += a * i + b
    if pre2<0:
        pre2=0
    pre2 = int(round(pre2))
    print "pre2",pre2
    return pre2


def lsm__2nd_model(data_list, train_list,endTime):
    ########lsm 2nd model(n days)###########
    #train_list = outlier_process(train_list)
    train_list = outlier_process1(data_list, train_list)
    
    a0 = 0.0
    a1 = 0.0
    a2 = 0.0
    tempa = 0.0
    temp0 = 0.0
    temp1 = 0.0
    temp2 = 0.0
    sy = 0.0
    sx = 0.0
    sxx = 0.0
    syy = 0.0
    sxy = 0.0
    sxxy = 0.0
    sxxx = 0.0
    sxxxx = 0.0
    pre3 = 0.0
    n = len(train_list)
    for i in range(len(train_list)):
        # if i < 32:
        #     p = i % 32
        # else:
        #     p = i % 32 +1
        sx = sx + i
        sy = sy + train_list[i]
        sxx = sxx + i * i
        sxxx = sxxx + i * i * i
        sxxxx = sxxxx + i * i * i * i
        sxy = sxy + i * train_list[i]
        sxxy = sxxy + i * i * train_list[i]
        syy = syy + train_list[i] * train_list[i]

    tempa = n * (sxx * sxxxx - sxxx * sxxx) - sx * (sx * sxxxx - sxx * sxxx) + sxx * (sx * sxxx - sxx * sxx)
    temp0 = sy * (sxx * sxxxx - sxxx * sxxx) - sxy * (sx * sxxxx - sxx * sxxx) + sxxy * (sx * sxxx - sxx * sxx)
    temp1 = n * (sxy * sxxxx - sxxy * sxxx) - sx * (sy * sxxxx - sxx * sxxy) + sxx * (sy * sxxx - sxy * sxx)
    temp2 = n * (sxx * sxxy - sxy * sxxx) - sx * (sx * sxxy - sy * sxxx) + sxx * (sx * sxy - sy * sxx)
    a0 = temp0 * 1.0 / tempa
    a1 = temp1 * 1.0 / tempa
    a2 = temp2 * 1.0 / tempa
    time_spam = (data_beg -endTime).days-1
    window = (data_end - data_beg).days
    for i in range(window):
        pre3 += a0 + a1 * (len(train_list) + i+time_spam) + a2 * (i + len(train_list)+time_spam) * (i + len(train_list)+time_spam)
    if pre3<0:
        pre3=0
    pre3 = int(round(pre3))
    print "pre3",pre3
    return pre3

def linear_regression_model(data_list, train_list,endTime):
    ########linear regression#########
    try:
        train_list = outlier_process(data_list,train_list)
    except Exception:
        print "success"
        return naive_model(data_list, train_list)
    else:
        #train_list = outlier_process(train_list)
        ySum = 0
        time_spam = (data_beg -endTime).days-1
        for i in range((data_end - data_beg).days+time_spam):
            yHat = linear_regression_predict(train_list)
            yy = yHat.toList()[0][0]
            train_list.append(yy)
            # train_list.append(yHat)
            # yy=yHat.toList()[0][0]
            if i>=time_spam:
                ySum += yy
        pre4 = int(round(ySum))
        if pre4<0:
            pre4 = 0
        print "pre4",pre4
        return pre4

def moving_average_model(data_list, train_list,endTime):
    ########movingaverage model ##########
    #train_list = outlier_process(train_list)  
    #train_list = outlier_process1(data_list,train_list)
    movingaverage = []
    averagedifference = []
    window = (data_end-data_beg).days
    totaldiff = 0
    time_spam = (data_beg -endTime).days-1
    for i in range(len(train_list)):
        movingtotal = 0
        if i+window < len(train_list):
            for j in range(window):
                movingtotal = movingtotal + train_list[i+j]
            movingaverage.append(movingtotal*1.0/window)
    #print movingaverage    
    for i in range(len(movingaverage)):
        if (i+1) < len(movingaverage):
            averagedifference.append(movingaverage[i+1]-movingaverage[i])
    #print averagedifference
    for i in range(len(averagedifference)):
        totaldiff = totaldiff + averagedifference[i]
    average = totaldiff/len(averagedifference)
    pre5 = (movingaverage[len(movingaverage)-1] + average * (window+time_spam))*window
    #predict_val = (sum(train_list)*1.0 / len(data_list) + average * window) * window
    if pre5 < 0:
        pre5 = 0
    pre5 = int(pre5)
    print "pre5",pre5
    return pre5

def exponential_smoothing_2nd_model(data_list, train_list,endTime):
    #############Exponential_smoothing model###########
    #异常值处理
    try:
        train_list = outlier_process(data_list,train_list)
    except Exception:
        return naive_model(data_list,train_list)
    else:
        #train_list = outlier_process1(data_list,train_list)
        alpha = 0.1
        s_single = exponential_smoothing(alpha, train_list)
        s_double = exponential_smoothing(alpha, s_single)
        a_double=[]
        b_double=[]
        time_spam = (data_beg -endTime).days-1
        for i in range(len(data_list)):
            a_double.append(2*s_single[i]-s_double[i])
            b_double.append((alpha/(1-alpha))*(s_single[i]-s_double[i]))
        s_pre_double = [0]*len(s_double)
        pre6 = 0
        y_pre=[]
        for i in range(1, len(data_list)):
            s_pre_double[i] = a_double[i-1]+b_double[i-1]
            if s_pre_double[i]<0:
                s_pre_double[i] = 0
            y_pre.append(int(round(s_pre_double[i])))
        #print y_pre
        #rmse = map(lambda x:(x[0]-x[1])**2,zip(y_pre,train_list)) 
        #print "mse",sum(rmse)*1.0/len(data_list)
        #print rmse
        for i in range((data_end - data_beg).days):
            pre6 += a_double[-1]+b_double[-1]*(i+1+time_spam)
        if pre6<0:
            pre6=0
        pre6 = int(round(pre6))
        print "pre6",pre6
        return pre6

def exponential_smoothing_3th_model(data_list, train_list):
    #异常值处理
    try:
        train_list = outlier_process(data_list,train_list)
    except  Exception:
        pass
    else:
        #train_list = outlier_process1(data_list,train_list)    
        alpha = 0.1
        s_single = exponential_smoothing(alpha, train_list)
        s_double = exponential_smoothing(alpha, s_single)
        s_triple = exponential_smoothing(alpha, s_double)
        a_triple=[]
        b_triple=[]
        c_triple=[]
        for i in range(len(data_list)): 
            a_triple.append(3*s_single[i]-3*s_double[i]+s_triple[i])
            b_triple.append ((alpha/(2*((1-alpha)**2)))*((6-5*alpha)*s_single[i] -
                                                   2*((5-4*alpha)*s_double[i])+(4-3*alpha)*s_triple[i]))
            c_triple.append(((alpha**2)/(2*((1-alpha)**2)))*(s_single[i]-2*s_double[i]+s_triple[i]))
        y_pre=[]
        pre7=0
        for i in range((data_end - data_beg).days):
            pre7 += a_triple[-1]+b_triple[-1]*(1+i) + c_triple[-1]*((1+i)**2)
        pre7 = int(round(pre7))
        print "pre7",pre7
        return pre7

def predict(name_p, data_p):
    '''预测方法'''
    data_list, train_list,endTime = deal_train_data(name_p, data_p)
    pre1 = naive_model(data_list, train_list)
    data_list, train_list,endTime = deal_train_data(name_p, data_p)
    pre2 = lsm__1st_model(data_list, train_list,endTime)
    data_list, train_list,endTime = deal_train_data(name_p, data_p)
    pre3 = lsm__2nd_model(data_list, train_list,endTime)
    #data_list, train_list,endTime = deal_train_data(name_p, data_p)
    #pre4 = linear_regression_model(data_list, train_list,endTime)
    data_list, train_list,endTime = deal_train_data(name_p, data_p)
    pre5 = moving_average_model(data_list, train_list,endTime)
    data_list, train_list,endTime = deal_train_data(name_p, data_p)
    pre6 = exponential_smoothing_2nd_model(data_list, train_list,endTime)
    #predict_val = int(round(5.0/15*pre1+3.0/15*pre2+1.0/15*pre3 +2.0/15*pre5+4.0/15*pre6))
    predict_val = int(round(3.0/6*pre1+1.0/6*pre2+2.0/6*pre6))    
    #print predict_val
    print predict_val
    return predict_val


def data_split(data):
    '''将日期处理成年月日时分秒'''

    data = data.strip("\r\n")
    data_y = data.split(" ")[0].split("-")
    data_y.extend(data.split(" ")[1].split(":"))
    for index, item in enumerate(data_y):
        if item == "08":
            data_y[index] = "8"
        if item == "09":
            data_y[index] = "9"
    data_y = map(eval, data_y)
    data = datetime.datetime(data_y[0], data_y[1], data_y[2], data_y[3], data_y[4], data_y[5])
    return data


def deal_input(input_l):
    '''处理输入文件'''
    for i in range(len(input_l)):
        input_l[i] = input_l[i].strip()
    # 提供的服务器
    val = input_l[0].split(" ")
    s_v = Serverdraw(val[0], val[1])

    # 要求预测虚拟机的种类数
    kindNum_vm = int(input_l[2])

    # 要求预测的参数
    req_type = input_l[4 + kindNum_vm ]

    # 要求预测虚拟机型号 以字典的形式存储在列表中
    kind = []
    for index in range(3, 3 + kindNum_vm):
        kind.append({})
        val = input_l[index].split(" ")  # 'flavor2' '1' '2048'
        kind[index - 3]['name'] = val[0]
        kind[index - 3]['cpu'] = int(val[1])
        kind[index - 3]['mem'] = int(val[2])

    # 预测的起止时间  年月日时分秒形式
    data_beg = data_split(input_l[6 + kindNum_vm])
    data_end = data_split(input_l[7 + kindNum_vm])

    return s_v, req_type, kindNum_vm, kind, data_beg, data_end


def deal_train_data(fal_name, traindata):
    '''处理训练数据  输入参数：虚拟机型号   返回参数：出现的时间对应的次数 列表'''
    createTime = []
    data_list = []
    train_list = []

    startTime = None
    endTime = None
    creTime = None
    # 训练集的起止时间  年月日时分秒形式
    data_beg = data_split(traindata[0].split("\t")[2])
    data_end = data_split(traindata[len(traindata)-1].split("\t")[2])
    startTime = datetime.datetime(data_beg.year, data_beg.month, data_beg.day, 0, 0, 0)
    endTime = datetime.datetime(data_end.year, data_end.month, data_end.day, 0, 0, 0)
    for index, item in enumerate(traindata):
        values = item.split("\t")
        if values[1] == fal_name:
            creTime = data_split((values[2]))
            createTime.append(creTime)

            # temp = data_split((values[2]))
    for index in range((endTime - startTime).days + 1):
        count = 0  # 统计个数
        for i in createTime:
            if (startTime + datetime.timedelta(index)).date() == i.date():
                count = count + 1
        train_list.append(count)
        # data_list.append(startTime + datetime.timedelta(index))
        data_list.append(index)
    return data_list, train_list,endTime


def swap(a, b):
    temp = a
    a = b
    b = temp
    return a, b


def predict_vm(ecs_lines, input_lines):
    result = [0]
    # Do your work from here#
    # 处理输入文件
    global data_beg, data_end
    s_v, req_type, kindnum_vm, r_kind, data_beg, data_end = deal_input(input_lines)
    # 参数含义  s_v: 服务器类  req_type： 要求放置的属性 cpu或者mem
    # kindnum_vm: 要求预测的虚拟机种类  r_kind: 要求预测种类虚拟机字典  data_beg,data_end: 要求预测的起止时间

    vm = []  # 需要预测的 flavor 对象列表
    for i in range(kindnum_vm):
        vm.append(ReqFlavor(r_kind[i]['name'], r_kind[i]['cpu'], r_kind[i]['mem'], ecs_lines))

        

    # ####################################第一问止####################################################################
    # ---------------------------------------------------------------------------------------------------------------
    # ####################################第二问始####################################################################

    vmtoput = []
    for i in range(len(vm)):
        temp_preval = vm[i].pre_val
        for j in range(temp_preval):
            # vm[i].pre_val = 1
            vmtoput.append(vm[i])

    min_server = len(vmtoput) + 1
    res_server = []
    T = 20.0
    Tmin = 12
    r = 0.9999
    dice = []
    for i in range(len(vmtoput)):
        dice.append(i)

    new_vmtoput = []
    while (T > Tmin):
        new_vmtoput = vmtoput

        random.shuffle(dice)
        new_vmtoput[dice[0]], new_vmtoput[dice[1]] = swap(new_vmtoput[dice[0]], new_vmtoput[dice[1]])

        server = []

        if len(server) == 0:
            serverin = Serverin()
            server.append(serverin)

        for i in range(len(new_vmtoput)):
            put = 0

            for j in range(len(server)):
                if server[j].totalcpu + new_vmtoput[i].cpu <= int(s_v.cpu) and server[j].totalmem + new_vmtoput[
                    i].mem / 1024 <= int(s_v.mem):
                    server[j].vm_list.append(new_vmtoput[i])
                    server[j].totalcpu = server[j].totalcpu + new_vmtoput[i].cpu
                    server[j].totalmem = server[j].totalmem + new_vmtoput[i].mem / 1024
                    put = 1
                    # print server[j].totalcpu
                    # print server[j].totalmem
                    break

            if put == 0 and new_vmtoput[i].cpu <= int(s_v.cpu) and new_vmtoput[i].mem / 1024 <= int(s_v.mem):
                serverin = Serverin()
                serverin.vm_list.append(new_vmtoput[i])
                serverin.totalcpu = new_vmtoput[i].cpu
                serverin.totalmem = new_vmtoput[i].mem / 1024
                server.append(serverin)

        server_num = 0.0       
        if req_type == 'CPU':
            server_num = len(server) - 1 + server[-1].totalcpu / int(s_v.cpu)

        if req_type == 'MEM':
            server_num = len(server) - 1 + server[-1].totalmem / int(s_v.mem)


        if server_num < min_server:
            min_server = server_num
            res_server = server
            vmtoput = new_vmtoput

        T = r * T

    yuzhi_cpu = 0  # 删除存放物体的利用率阈值
    yuzhi_mem = 0
    sum_cpu = 0
    sum_mem = 0
    rt = 0.0  # 利用率

    for i in range(kindnum_vm):
        yuzhi_cpu += int(vm[i].cpu)
        yuzhi_mem += int(vm[i].mem)/1024

    for i in range(len(res_server)):
        sum_cpu = 0
        sum_mem = 0
        for j in res_server[len(res_server)-1-i].vm_list:
            sum_cpu += int(j.cpu)
            sum_mem += int(j.mem)/1024
        if int(sum_cpu) < yuzhi_cpu and int(sum_mem) < yuzhi_mem:
            for j in res_server[len(res_server)-1-i].vm_list:
                j.pre_val -= 1
            res_server.pop(len(res_server)-1-i)
            break

    total = 0  # 预测值之和
    for i in range(kindnum_vm):
        pre_val = vm[i].pre_val
        total = total + pre_val
        result.append(vm[i].name + " " + str(pre_val))
    result[0] = total


    result.append(' ')
    result.append(len(res_server))
    for i in range(len(res_server)):
        output1 = []
        output1.append(str(i + 1))
        for j in range(len(res_server[i].vm_list)):
            output1.append(res_server[i].vm_list[j].name + " 1")
        output1 = ' '.join(output1)
        result.append(output1)


    if ecs_lines is None:
        print 'ecs information is none'
        return result
    if input_lines is None:
        print 'input file information is none'
        return result

    return result