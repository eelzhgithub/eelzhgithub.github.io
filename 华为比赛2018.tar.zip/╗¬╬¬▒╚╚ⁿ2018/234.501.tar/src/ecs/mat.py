# coding=utf-8

import copy

def is_num(val):
	return isinstance(val, (int, float, long))
def is_list(val):
	return isinstance(val, list)
def is_num_list(arr):
	if not is_list(arr):
		return False
	for item in arr:
		if not is_num(item):
			return False
	return True

class mat:
	def __init__(self, init):
		self.array = self.process(init)
		self.__T = None 
		self.__I = None 

	def __mul__(self, other):
		mat1 = self.array
		if isinstance(other, mat):
			mat2 = other.array
			result = []
			mat1H = len(mat1)
			mat1W = len(mat1[0])
			mat2H = len(mat2)
			mat2W = len(mat2[0])
			if mat1W != mat2H:
				raise TypeError('weishu error')

			for i in range(mat1H):
				result.append([])
				for j in range(mat2W):
					val = 0.0
					for k in range(mat1W):
						val += mat1[i][k]*mat2[k][j]
					result[i].append(val)
			return mat(result)
		elif is_num(other): # 与数字相乘
			result = []
			matH = len(mat1)
			matW = len(mat1[0])
			for i in range(matH):
				result.append([])
				for j in range(matW):
					result[-1].append(self.array[i][j] * other)
			return mat(result)
		else:
			raise TypeError('matrix number multiply')


	def __str__(self):
		return 'matrix:\n' + str(self.array)

	def __getattr__(self, attr):
		if attr == 'T':
			if self.__T is None:
				self.__T = self.transpose()
			return copy.deepcopy(self.__T)
		elif attr == 'I':
			if self.__I is None:
				self.__I = self.inverse()
			return copy.deepcopy(self.__I)
		else:
			raise AttributeError('there is no {0}'.format(attr))


	def toList(self):
		return copy.deepcopy(self.array)

	def transpose(self):
		array = self.array
		matT = []
		h = len(array)
		w = len(array[0])
		for i in range(w):
			matT.append([])
			for j in range(h):
				matT[i].append(array[j][i])
		return mat(matT)

	def inverse(self):
		array = self.array
		extend_matrix = copy.deepcopy(array)
		l = len(array)
		for i in range(0, l):   
			extend_matrix[i].extend([0]*i)
			extend_matrix[i].extend([1])
			extend_matrix[i].extend([0]*(l-i-1))
		for i in range(0, len(extend_matrix)):   
			if extend_matrix[i][i] == 0:
				for j in range(i, len(extend_matrix)):
					if extend_matrix[j][i] != 0:
						extend_matrix[i], extend_matrix[j] = extend_matrix[j], extend_matrix[i]
						break
				if j >= len(extend_matrix):
					print 'no inverse matrix'
					return 0
				break
		for i in range(0, len(extend_matrix)):   
			f = extend_matrix[i][i]
			for j in range(0, len(extend_matrix[i])):    
				extend_matrix[i][j] /= float(f)

			for m in range(0, len(extend_matrix)):
				if m == i:
					continue
				b = extend_matrix[m][i]
				for n in range(0, len(extend_matrix[i])):    
					extend_matrix[m][n] -= extend_matrix[i][n] * b
		for i in range(0, len(extend_matrix)):
			extend_matrix[i] = extend_matrix[i][l:]
		return mat(extend_matrix)
    

	def process(self, init):
		if not is_list(init):
			if is_num(init):
				return [[init]]
			else:
				raise TypeError('only support number array')
		else:
			if is_list(init[0]):
				for item in init:
					if not is_num_list(item):
						raise TypeError('only support number array')
				return init
			elif is_num_list(init):
				return [init]
			else:
				raise TypeError('only support number array')


	def det(self):
		array = self.array
		if len(array) <= 0:  
			return None  
		if len(array) == 1:  
		    return array[0][0]  
		else:  
		    s = 0  
		    for i in range(len(array)):  
		        n = mat([[row[a] for a in range(len(array)) if a != i] for row in array[1:]])
		        if i % 2 == 0:  
		            s += array[0][i] * n.det() 
		        else:  
		            s -= array[0][i] * n.det()  
		    return s 

     


            
        



