//连接相关头文件

#ifndef __UKEY_CONNECTION_H_
#define __UKEY_CONNECTION_H_

#include "event.h"
#include "memory_pool.h"
#include "thread_pool.h"

typedef struct connections_s connections_t;

//一个连接的数据结构
struct connections_s {
	event_t *read; //需要调用的读事件，这是一个函数
	event_t *write; //需要调用的写事件

	ukey_pool_t *m_cpool;//内存池
};

typedef struct manager_s manager_t;

//管理全局的句柄
struct manager_s {
	int ep_fd;//epoll句柄？关注这个epoll句柄
	struct epoll_event *ep_events;//epoll关注的事件数组
	int nep_events;//epoll事件个数
	
	connections_t *conn;//连接实体
	int nconnections;//连接数

	threadpool_t *t_pool;//线程池
	ukey_pool_t *m_pool;//内存池
	
	pthread_mutex_t conn_lock;//锁
};


struct manager_s g_manager;

void conn_init(connections_t *c, int size);

int conn_set(int fd, int events, void (*call_back)(int, int, void *)); 

void conn_free(int fd);


#endif
