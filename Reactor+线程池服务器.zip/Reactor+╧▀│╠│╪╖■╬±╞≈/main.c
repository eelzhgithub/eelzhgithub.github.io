#include "connection.h"
#include "httpd.h"

int main(int argc, char *argv[])
{
	//初始化内存池，线程池，预先分配连接作为epoll关注列表
	if (manager_init() != 0) {
		fprintf(stderr, "manager init error\n");
		return -1;;
	}

	//创建监听套接字
	struct sockaddr_in server_addr;
	int listen_fd;
	int ep_fd = g_manager.ep_fd;

	if((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket error");
		exit(1);
	}

	//这个函数对应就是把IO得到的文件描述符的事件给后台计算线程处理
	//IO线程只负责调用listen进行倾听，得到待接收队列
	//计算线程每个线程accept一个连接，处理该连接的所有工作
	//初始化连接设置，本listen_fd收到的所有读操作，都把accept之类的工作放到线程池中，由计算线程完成剩余工作
	//调用完后，epoll函数会关注listenfd上的读，如果有内容，它会调用add_conn函数(把accept放到线程池里让计算线程处理剩下操作)
	if (conn_set(listen_fd, EPOLLIN, (void *)add_conn) < 0) {
		fprintf(stderr, "listen fd:conn set error\n");
		exit(-1);
	}

	//监听端口属性设置
	bzero(&server_addr, sizeof(server_addr));

	//设置端口复用
	int flag = 1;
	setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)); //SOL_SOCKET:基本套接口 SO_REUSERADDR,允许重用本地地址和端口(在timewait状态时)
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port = htons(SERV_PORT);

	bind(listen_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
	listen(listen_fd, 20); //20是允许套接字排队的最大连接个数，这只是一个设置


	while(1)
	{
		//非阻塞在epoll_wait()，使用非阻塞+ET模式
		//目前epoll_wait只关注listenfd上的连接，可以有多个客户端连接本listenfd
		int event_count = epoll_wait(ep_fd, g_manager.ep_events, g_manager.nep_events, -1);
		if(event_count < 0)
		{
			perror("epoll wait error");
			exit(1);
		}
		int i = 0;
		for(; i < event_count; i++)
		{
			int fd = g_manager.ep_events[i].data.fd; //得到连接的描述符
			int events = g_manager.ep_events[i].events; //得到连接对应的事件类型
			connections_t *ev_conn = &g_manager.conn[fd]; //找到触发事件的实体

			if (ev_conn == NULL)
				continue;
			//如果是读事件
			if (events & EPOLLIN) {
				if (ev_conn->read) { //如果有事件挂在连接上
					//new_conn->read = new_ev
					event_t *read_ev = ev_conn->read; //取得对应的事件
					if (read_ev->ev_callback) //若有回调函数，执行回调函数，这里就是执行add_conn函数了
						read_ev->ev_callback(read_ev->ev_fd, read_ev->ev_events, read_ev->ev_arg);
				}
			}
			//如果是写事件
			if (events & EPOLLOUT) {
				if (ev_conn->write) {
					event_t *write_ev= ev_conn->write;
					write_ev->ev_callback(write_ev->ev_fd, write_ev->ev_events, write_ev->ev_arg);
				}
			}
			/* 需要扩展epoll_event数组 */
			if (event_count == g_manager.nep_events) {
				if (epev_ralloc() < 0) {
					fprintf(stderr, "epoll event realloc error\n");
					exit(-1);
				}
			}
		}
	}

	//close函数可以封装到一个智能指针对象里面，如果对象离开作用域，其析构函数会自动执行close函数，可以避免由于一些错误而无法执行到这个close
	close(listen_fd);
	manager_destroy();
	return 0;
}


