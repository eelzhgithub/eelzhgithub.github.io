//定义连接相关类型及操作

#include "connection.h"

void conn_init(connections_t *c, int size) {	
	int i;
	for (i = 0; i < size; i++) {
		c[i].m_cpool = ukey_create_pool(1024); //每个connection维护一个1k的内存池
		c[i].read = NULL;
		c[i].write = NULL;
	}
}

//参数:listenfd,EPOLLIN,(void *)add_conn
//调用完后，epoll函数会关注listenfd上的读，如果有内容，它会调用add_conn函数(把accept放到线程池里让计算线程处理剩下操作)
int conn_set(int fd, int events, void (*call_back)(int, int, void *)) {
	if (fd > g_manager.nconnections) {
		fprintf(stderr, "fd max limits\n");
		return -1;
	}

	//找到对应的连接预先分配给他的空间
	connections_t *new_conn = &g_manager.conn[fd];
	if (new_conn == NULL) {
		fprintf(stderr, "conn set error\n");
		return -1;
	}

	//在连接的内存空间中分配一个事件的空间
	event_t *new_ev = (event_t *)ukey_palloc(new_conn->m_cpool, sizeof(event_t));
	if (new_ev == NULL) {
		fprintf(stderr, "alloc from coon m_cpoll error\n");
		return -1;
	}
	void *arg = (void *)new_ev;
	event_set(new_ev, fd, call_back, arg);//设置事件，包括关注的fd,回调函数
	event_add(g_manager.ep_fd, events, new_ev, 1);//epoll关注列表添加事件，跟epoll说明这是读事件还是写事件，1表示设置为非阻塞epoll ET触发

	//根据传入的参数设置对应的事件类型是读还是写
	if (events & EPOLLIN) {
		new_conn->read = new_ev;//这个接口体里包含回调函数，最后此fd如果是读，调用这里的回调函数
	}
	if (events & EPOLLOUT) {
		new_conn->write = new_ev;
	}
	
	return 0;
}	

void conn_free(int fd) {
	
	if (fd == -1)
		return;
	connections_t *c = &g_manager.conn[fd];
	if (c == NULL)
		return ;
	if (c->read != NULL) {
		event_del(g_manager.ep_fd, c->read);
		event_set(c->read, -1, NULL, 0);
		
	} else if (c->write != NULL) {
		event_del(g_manager.ep_fd, c->write);
		event_set(c->write, -1, NULL, 0);
	}
}
