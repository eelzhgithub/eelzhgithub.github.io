#ifndef __UKEY_EVENT_H_
#define __UKEY_EVENT_H_

#include <stdio.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <unistd.h>
#include <fcntl.h>

typedef struct event_s event_t;

//一个事件的数据结构
struct event_s {
	int ev_fd; //事件的描述符
	void (*ev_callback)(int, int, void *ev_arg); //执行事件的回调函数，它的输入参数包括int,int,还有一个函数的参数指针
	void *ev_arg; //回调函数的参数
	int ev_events; //事件类型EPOLLIN还是EPOLLOUT
	int ev_status; //表示的事件的状态,是否已经在epoll监听中
};

void event_set(event_t *ev, int fd, void (*call_back)(int, int, void *), void *arg); 

void event_add(int ep_fd, int events, event_t *ev, int et_flag);

void event_del(int ep_fd, event_t *ev); 

#endif
