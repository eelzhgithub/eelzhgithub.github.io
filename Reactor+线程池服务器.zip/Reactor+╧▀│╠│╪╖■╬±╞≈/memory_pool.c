//内存池设计
//采用两个链表分别管理大块内存和小块内存
//当某次申请的内存大小大于内存池最大可能申请得到的内存空间时，直接使用malloc分配
//小于最大分配内存空间，则按照首次适应分配，遍历当前所有的链表，如果所有链表都没有空间，则申请新的内存块，添加到链表尾


#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <unistd.h>
#include "memory_pool.h"


static void *ukey_palloc_block(ukey_pool_t *pool, int size);
static void *ukey_palloc_large(ukey_pool_t *pool, int size);


ukey_pool_t *ukey_create_pool(int size) {
	ukey_pool_t *p;

	int page_size = getpagesize();
	int type_len = sizeof(ukey_pool_t);//初始的时候，这个值很小，因为没有任何数据
	if (size <= type_len) {
		fprintf(stderr, "create too small memory pool\n");
		return NULL;
	}
	p = memalign(UKEY_POOL_ALIGNMENT, size);
	if (p == NULL) {
		return NULL;
	}

	p->small.last = (char *)p + type_len; //初始状态：last指向ngx_pool_t结构体之后数据取起始位置
	p->small.end = (char *)p + size;//end指向分配的整个size大小的内存的末尾
	p->small.next = NULL;
	p->small.failed = 0;

	//#define NGX_MAX_ALLOC_FROM_POOL  (ngx_pagesize - 1)
	//内存池最大不超过4095，x86中页的大小为4K
	size -= type_len;
	p->max = (size < page_size) ? size : page_size;//如果分配的size太大了，最多也只能按照规定的最大来分配
	page_size = p->max;
	p->current = p;
	p->large = NULL;//这里有一个指向大块内存的指针，在有大块内存的时候用

	return p;
}

//销毁内存池，按照大块内存和小块内存，分别遍历销毁
void ukey_destroy_pool(ukey_pool_t *pool) {
	ukey_pool_t *p, *n;
	ukey_pool_large_t *l;

	for (l = pool->large; l; l = l->next) {
		if (l->alloc) {
			free(l->alloc);
			l->alloc = NULL;
		}
	}
	
	for (p = pool, n = pool->small.next; ; p = n, n = n->small.next) {
		free(p);
		if (n == NULL) {
			break;
		}
	}
}

//重置内存池
void ukey_reset_pool(ukey_pool_t *pool) {
	ukey_pool_t *p;
	ukey_pool_large_t *l;

	//大块内存释放
	for (l = pool->large; l; l = l->next) {
		if (l->alloc) {
			free(l->alloc);
			l->alloc = NULL;
		}	
	}

	pool->large = NULL;

	//小块内存的指针尾部直接恢复至现在内存池的大小尾端位置
	for (p = pool; p; p = p->small.next) {
		p->small.last = (char *)p + sizeof(ukey_pool_t);
	}
}

//从内存池中申请内存(对齐之后)
void *ukey_palloc(ukey_pool_t *pool, int size) {
	ukey_pool_t *p;
	char *m = NULL;

	//如果申请的内存大小大于内存池的max值，则走另一条路，申请大内存
	if (size <= pool->max) {
		p = pool->current;

		do {
			m = (char *)((unsigned long)((p->small.last) + (UKEY_POOL_ALIGNMENT - 1)) & (unsigned long)~(UKEY_POOL_ALIGNMENT - 1));
			if ((int)(p->small.end - m) >= size) {
				p->small.last = m + size;
				return m;
			}
			p = p->small.next;
		} while (p);

		return ukey_palloc_block(pool, size);
	}

	return ukey_palloc_large(pool, size);
}

static void *ukey_palloc_block(ukey_pool_t *pool, int size) {
	char *m;
	int psize;
	ukey_pool_t *p, *new, *current;

	psize = (int)(pool->small.end - (char *)pool);

	m = memalign(UKEY_POOL_ALIGNMENT, psize);
	if (m == NULL) {
		return NULL;
	}

	new = (ukey_pool_t *)m;

	new->small.end = m + psize;
	new->small.next = NULL;
	new->small.failed = 0;

	m += sizeof(ukey_pool_data_t);
	m = (char *)((unsigned long)(m + (UKEY_POOL_ALIGNMENT - 1)) & (unsigned long)~(UKEY_POOL_ALIGNMENT - 1));
	new->small.last = m + size;

	current = pool->current;

	for (p = current; p->small.next; p = p->small.next) {
		if (p->small.failed++ > 4) {
			current = p->small.next;
		}
	}

	p->small.next = new;

	pool->current = current ? current : new;

	return m;
}

//当某次申请的内存大小大于内存池最大可能申请到的内存空间时，直接使用malloc分配
static void *ukey_palloc_large(ukey_pool_t *pool, int size) {
	void *p;
	ukey_pool_large_t *l;

	p = malloc(size);
	if (p == NULL) {
		return NULL;
	}

	for (l = pool->large; l; l = l->next) {
		if (l->alloc == NULL) {
			l->alloc = p;
			return p;
		}
	}

	//从内存池中申请内存(对齐之后)
	l = ukey_palloc(pool, sizeof(ukey_pool_large_t));
	if (l == NULL) {
		free(p);
		p = NULL;
		return NULL;
	}

	l->alloc = p;
	l->next = pool->large;
	pool->large = l;

	return p;
}

void *ukey_pnalloc(ukey_pool_t *pool, int size) {
	char *m;
	ukey_pool_t *p;

	if (size <= pool->max) {
		p = pool->current;

		do {
			m = p->small.last;

			if ((int)(p->small.end - m) >= size) {
				p->small.last = m + size;

				return m;
			}
			p = p->small.next;
		} while (p);

		return ukey_palloc_block(pool, size);
	}
	return ukey_palloc_large(pool, size);
}

void *ukey_pcalloc(ukey_pool_t *pool, int size) {
	void *p;

	p = ukey_palloc(pool, size);
	if (p) {
		memset(p, 0, size);
	}
	return p;
}

int ukey_pfree(ukey_pool_t *pool, void *p) {
	ukey_pool_large_t *l;

	for (l = pool->large; l; l = l->next) {
		if (p == l->alloc) {
			free(p);
			l->alloc = NULL;
			return 0;
		}
	}
	return -1;
}


