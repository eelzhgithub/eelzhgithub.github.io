#ifndef _UKEY_MEMORY_POOL_H_INCLUDED_
#define _UKEY_MEMORY_POOL_H_INCLUDED_

//大块内存的数据结构

//#define UKEY_MAX_ALLOC_FROM_POOL 4095
#define UKEY_POOL_ALIGNMENT 16

typedef struct ukey_pool_large_s ukey_pool_large_t;
typedef struct ukey_pool_data_s ukey_pool_data_t;
typedef struct ukey_pool_s ukey_pool_t;

//内存块？大块内存数据结构
struct ukey_pool_large_s {
	ukey_pool_large_t *next;//内存块
	void *alloc;
};

//内存池数据块结构，这是内存池里面的一小部分
struct ukey_pool_data_s {
	char *last;//当前内存池分配到末位地址，即下一次分配从此处开始。
	char *end;//当前内存池结束位置；
	ukey_pool_t *next;//内存池里面有很多块内存，这些内存块就是通过该指针连成链表的，next指向下一块内存。
	int failed;//内存池分配失败次数
};

//内存池头部结构。//内存池结构体，维护了两个链表，一条管理大块内存，一条管理小块内存
struct ukey_pool_s {
	ukey_pool_data_t small;//小内存块

	int	max;//内存池数据块的最大值

	ukey_pool_t *current;//指向当前内存池

	ukey_pool_large_t *large;//大块内存的链表，即分配空间超过max的情况使用
};

ukey_pool_t *ukey_create_pool(int size); //创建内存池
void ukey_destroy_pool(ukey_pool_t *pool); //销毁内存池
void ukey_reset_pool(ukey_pool_t *pool); //重置内存池

void *ukey_alloc(int size);
void *ukey_calloc(int size);

void *ukey_palloc(ukey_pool_t *pool, int size); //从内存池中申请内存(对齐之后)
void *ukey_pnalloc(ukey_pool_t *pool, int size); //从内存池中申请内存(不对齐之后)
void *ukey_pcalloc(ukey_pool_t *pool, int size); //从内存池中申请内存并初始化为0
//void *ukey_pmemalign(ukey_pool_t *pool, int size, int alignment);
int  ukey_pfree(ukey_pool_t *pool, void *p); //内存清除//释放内存池中的大块内存


#endif
