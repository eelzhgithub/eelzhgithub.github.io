#include "event.h"


void event_set(event_t *ev, int fd, void (*call_back)(int, int, void *), void *arg) {

	ev->ev_fd = fd; //事件的描述符
	ev->ev_callback = call_back; //事件的回调函数
	ev->ev_arg = arg; //参数
	ev->ev_events = 0; //事件类型EPOLLIN还是EPOLLOUT
	ev->ev_status = 0; //控制事件的状态，是否已经在epoll监听中

	return ;
}

void event_add(int ep_fd, int events, event_t *ev, int et_flag) {
	struct epoll_event ep_event = { 0,{0} }; //初始化epoll_event
	int option;//属性参数

	if (et_flag) {
		fcntl(ev->ev_fd, F_SETFL, O_NONBLOCK); //设置为非阻塞epoll ET触发
		events |= EPOLLET; //event加上ET触发
	}

	ep_event.data.fd = ev->ev_fd; //设置监听的描述符
	ep_event.events = ev->ev_events = events; //设置属性

	if (ev->ev_status == 1) {
		option = EPOLL_CTL_MOD; //如果之前已经在epoll中，则为修改
	} else {
		option = EPOLL_CTL_ADD; //之前没在epoll中，则为添加
		ev->ev_status = 1;
	}

	//epoll中注册事件
	if (epoll_ctl(ep_fd, option, ev->ev_fd, &ep_event) < 0) {
		perror("epoll ctl error");
		exit(-1);
	}
	return ;
}

void event_del(int ep_fd, event_t *ev) {

	int option;

	if (ev->ev_fd == -1)
		return ;

	option = EPOLL_CTL_DEL;

	if ((epoll_ctl(ep_fd, option, ev->ev_fd, 0)) < 0) {
		perror("del event error");
		return ;
	}
}
